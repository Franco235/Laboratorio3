package constantes;

public class TipoVehiculo {

    public static final String DOSPUERTAS = "2Puertas";
    public static final String CUATROPUERTAS = "4Puertas";
    public static final String CAMIONETA = "Camioneta";

}
